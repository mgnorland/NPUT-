package com.mmp.nput1.settings;

/**
 * Created by devdeeds.com on 1/10/17.
 */

public class Constants {

    public static final int LOCATION_INTERVAL = 10000;
    public static final int FASTEST_LOCATION_INTERVAL = 5000;
}
